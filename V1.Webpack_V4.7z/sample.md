If we want to create a new file via the cmd windows command line then use the below:

fsutil file createnew myEmptyFile.txt 0

0 - at end means the size of the file, means an empty file of 0 size - must give

eg: fsutil file createnew index.js 0
